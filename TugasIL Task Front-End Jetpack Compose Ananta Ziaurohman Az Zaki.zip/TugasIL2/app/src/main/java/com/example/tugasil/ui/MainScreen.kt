package com.example.tugasil.ui

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.List
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.tugasil.R

data class ItemData(val id: Int, val name: String, val description: String, val imageResId: Int)

val itemList = listOf(
    ItemData(id = 0, name = "Ederson Moraes", description = "Yang lahir pada 17 Agustus 1993 di Osasco, Brasil, adalah penjaga gawang utama Manchester City dengan kaki kiri sebagai kaki terkuatnya dan telah memenangkan banyak trofi termasuk Premier League, FA Cup, EFL Cup, serta Liga Champions pada 2023.", imageResId = R.drawable.`a`),
    ItemData(id = 1, name = "Kyle Walker", description = "Bek kanan berusia 34 tahun yang lahir di Sheffield, Inggris, dengan kaki kanan sebagai kaki terkuatnya, telah memenangkan berbagai trofi seperti Premier League, FA Cup, EFL Cup, serta menjadi bagian dari timnas Inggris di Piala Dunia 2018 dan Euro 2020.", imageResId = R.drawable.`b`),
    ItemData(id = 2, name = "Ruben Dias", description = "Yang lahir pada 14 Mei 1997 di Amadora, Portugal, adalah bek tengah yang menjadi pilar pertahanan City dengan kaki kanan sebagai kaki terkuatnya, memenangkan Premier League, FA Cup, EFL Cup, serta Liga Champions 2023.", imageResId = R.drawable.`c`),
    ItemData(id = 3, name = "John Stones", description = "Lahir pada 28 Mei 1994 di Barnsley, Inggris, dengan kaki kiri sebagai kaki terkuatnya, dikenal karena kemampuan bertahannya yang solid dan telah meraih Premier League, FA Cup, EFL Cup, serta menjadi bagian dari timnas Inggris di Euro 2020 dan Piala Dunia 2018.", imageResId = R.drawable.`d`),
    ItemData(id = 4, name = "Joao Cancelo", description = "Yang lahir pada 27 Mei 1994 di Barreiro, Portugal, adalah bek kiri serbaguna dengan kaki kiri sebagai kaki terkuatnya yang telah memenangkan Premier League, FA Cup, EFL Cup bersama City serta tampil impresif dengan kemampuan menyerangnya. ", imageResId = R.drawable.`e`),
    ItemData(id = 5, name = "Rodri", description = " Gelandang bertahan yang lahir pada 22 Juni 1996 di Madrid, Spanyol, dengan kaki kiri sebagai kaki terkuatnya, telah berperan besar dalam kesuksesan City dengan memenangkan Premier League, FA Cup, EFL Cup, dan Liga Champions 2023.", imageResId = R.drawable.`f`),
    ItemData(id = 6, name = "Kevin De Bruyne", description = " Gelandang serang asal Belgia yang lahir pada 28 Juni 1991 di Drongen, dengan kaki kanan sebagai kaki terkuatnya, telah menjadi pemain kunci bagi City dengan banyak assist, memenangkan Premier League, FA Cup, EFL Cup, dan Liga Champions.", imageResId = R.drawable.`g`),
    ItemData(id = 7, name = "Bernardo Silva", description = "Yang lahir pada 10 Agustus 1994 di Lisbon, Portugal, dengan kaki kanan sebagai kaki terkuatnya, adalah gelandang serba bisa yang telah meraih Premier League, FA Cup, EFL Cup, serta Liga Champions 2023.", imageResId = R.drawable.`h`),
    ItemData(id = 8, name = "Phil Foden", description = "Yang lahir pada 28 Mei 2000 di Stockport, Inggris, dengan kaki kiri sebagai kaki terkuatnya, adalah salah satu talenta muda terbaik yang telah meraih Premier League, FA Cup, EFL Cup, dan Liga Champions 2023.", imageResId = R.drawable.`i`),
    ItemData(id = 9, name = "Erling Haaland", description = "Striker asal Norwegia yang lahir pada 21 Juli 2000 di Leeds, Inggris, dengan kaki kanan sebagai kaki terkuatnya, mencetak banyak gol untuk City dan memenangkan Premier League, FA Cup, serta menjadi pencetak gol terbanyak di Premier League", imageResId = R.drawable.`j`)
)

@Composable
fun MainScreen() {
    val navController = rememberNavController()
    Scaffold(
        bottomBar = { BottomNavigationBar(navController) }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "listScreen",
            modifier = Modifier.padding(innerPadding)
        ) {
            composable("listScreen") { ListScreen(navController) }
            composable("detailScreen/{itemId}") { backStackEntry ->
                val itemId = backStackEntry.arguments?.getString("itemId")
                DetailScreen(navController, itemId)
            }
            composable("aboutScreen") { AboutScreen(navController) }
        }
    }
}

@Composable
fun ListScreen(navController: NavHostController) {
    Scaffold(
        topBar = { TopAppBarWithBack(navController = null, title = "Manchester City") }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
        ) {
            // Menambahkan gambar logo samar-samar di latar belakang
            Image(
                painter = painterResource(id = R.drawable.logo_background), // Replace with your logo's drawable ID
                contentDescription = null,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { alpha = 0.1f }, // Set opacity for subtle effect
                contentScale = ContentScale.Crop
            )

            // Overlay gradasi transparan di atas gambar
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color(0xFFBBDEFB), Color(0xFF0D47A1)),
                            startY = 0f,
                            endY = Float.POSITIVE_INFINITY
                        )
                    )
                    .graphicsLayer { alpha = 0.6f } // Set transparansi gradasi overlay
            )

            // Konten layar
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text(
                    text = "List Pemain",
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White
                )
                LazyRow(
                    modifier = Modifier.padding(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(itemList) { item ->
                        ItemRowSimple(item = item) {
                            navController.navigate("detailScreen/${item.id}")
                        }
                    }
                }

                Text(
                    text = "Line Up Pemain",
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White
                )
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(itemList) { item ->
                        ItemGridSimple(item = item) {
                            navController.navigate("detailScreen/${item.id}")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BottomNavigationBar(navController: NavHostController) {
    NavigationBar {
        NavigationBarItem(
            icon = { Icon(Icons.Default.List, contentDescription = "List Screen") },
            label = { Text("List") },
            selected = false,
            onClick = { navController.navigate("listScreen") }
        )
        NavigationBarItem(
            icon = { Icon(Icons.Default.Home, contentDescription = "Detail Screen") },
            label = { Text("Detail") },
            selected = false,
            onClick = { navController.navigate("detailScreen/0") }
        )
        NavigationBarItem(
            icon = { Icon(Icons.Default.Info, contentDescription = "About Screen") },
            label = { Text("About") },
            selected = false,
            onClick = { navController.navigate("aboutScreen") }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopAppBarWithBack(navController: NavHostController?, title: String) {
    TopAppBar(
        title = {
            Text(
                text = title,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.Bold
            )
        },
        navigationIcon = {
            if (navController != null) {
                IconButton(onClick = { navController.popBackStack() }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
            }
        }
    )
}

@Composable
fun ItemRowSimple(item: ItemData, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .width(160.dp)
            .clickable { onClick() }
    ) {
        Image(
            painter = painterResource(id = item.imageResId),
            contentDescription = item.name,
            modifier = Modifier
                .fillMaxWidth()
                .size(120.dp),
            contentScale = ContentScale.Crop
        )
        Text(
            text = item.name,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(8.dp),
            color = Color.White
        )
    }
}

@Composable
fun ItemGridSimple(item: ItemData, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .padding(4.dp)
            .clickable { onClick() }
    ) {
        Image(
            painter = painterResource(id = item.imageResId),
            contentDescription = item.name,
            modifier = Modifier
                .fillMaxWidth()
                .size(120.dp),
            contentScale = ContentScale.Crop
        )
        Text(
            text = item.name,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(8.dp),
            color = Color.White
        )
    }
}

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun DetailScreen(navController: NavHostController, itemId: String?) {
    val item = itemList.find { it.id.toString() == itemId }
    Scaffold(
        topBar = { TopAppBarWithBack(navController, title = "Detail Screen") }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFFBBDEFB), Color(0xFF0D47A1))
                    )
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                if (item != null) {
                    Image(
                        painter = painterResource(id = item.imageResId),
                        contentDescription = item.name,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                            .size(200.dp)
                    )
                    Text(
                        text = item.name,
                        style = MaterialTheme.typography.headlineSmall,
                        modifier = Modifier.padding(16.dp),
                        color = Color.White
                    )
                    Text(
                        text = item.description,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(16.dp),
                        color = Color.White
                    )

                    // Menambahkan LazyVerticalGrid di bawah detail item
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(itemList) { relatedItem ->
                            ItemGridSimple(item = relatedItem) {
                                navController.navigate("detailScreen/${relatedItem.id}")
                            }
                        }
                    }
                } else {
                    Text(
                        text = "Item tidak ditemukan",
                        style = MaterialTheme.typography.headlineSmall,
                        modifier = Modifier.padding(16.dp),
                        color = Color.White
                    )
                }
            }
        }
    }
}

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun AboutScreen(navController: NavHostController) {
    Scaffold(
        topBar = { TopAppBarWithBack(navController, title = "About") }
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFFBBDEFB), Color(0xFF0D47A1))
                    )
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.profile_picture),
                    contentDescription = "Profile Picture",
                    modifier = Modifier
                        .size(120.dp)
                        .padding(bottom = 16.dp)
                )
                Text(
                    text = "Nama: Ananta Ziuarohman Az Zaki",
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Email: anantaazaki1933@gmail.com",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White
                )
                Text(
                    text = "Institusi: Universitas Singaperbangsa Karawang",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White
                )
                Text(
                    text = "Prodi: Teknik Informatika",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewMainScreen() {
    MainScreen()
}
